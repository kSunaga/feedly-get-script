require 'httpclient'
require 'json'
require 'slack-notifier'

STREAM_ID = '8e3615ca-722b-486d-a741-378447ebd0d0'.freeze
ACCESS_TOKEN = 'AxwOKtF2V9zd9Ysfi8iJc93HN4LLB5h0IBPjZcPBLsjc6_Rlhekhhwvbz0Sp_iaZFC4kZcSooa1HlLSgNNovGlMU-TfDWJBmuLb_K9Wvqfj-o1WAM04yRYEdGpwr5l4VJLw4p4ZZLL8eAB6nuGBHlXN3BeIUM9rXf6nng7PubJFUzlgHYg7Sn2cD2EprVywxoyDeLCXpQhgPsAWAk51SyoJxWyRpfh08QK0ig_3s8UPL6GYr3h-P9lXIp_k:feedlydev'.freeze

def post_slack(content)
  message = ''
  notifier = Slack::Notifier.new('https://hooks.slack.com/services/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')
  content.each do |c|
    message << "\rタイトルは#{c[0]}\rURLは#{c[1]}です。\r"
  end
  notifier.ping("未読記事を報告します！\r#{message}")
end

def fetch_unread_articles
  article_title_and_url = []
  client = HTTPClient.new
  query = { unreadOnly: true }
  response = client.get("https://cloud.feedly.com/v3/streams/contents?streamId=user/#{STREAM_ID}/category/global.all", query: query, header: [["Authorization", ACCESS_TOKEN]])

  body = JSON.parse response.body

  body['items'].each do |item|
    article = []
    article.push(item['title'])
    article.push(item['originId'])
    article_title_and_url.push(article)
  end
  post_slack(article_title_and_url)
end

# 記事の既読api
# def articles_as_read
#   client = HTTPClient.new
#   body = { action: 'markAsRead', type: 'entries', entryId: '' }
#   header = {Authorization: ACCESS_TOKEN}
#   response = client.post('https://cloud.feedly.com/v3/markers', body: body, header: [[header]] )
# end

def lambda_handler(event:, context:)
  fetch_unread_articles
end
